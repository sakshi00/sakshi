package com.cg.ass.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ass.dto.Person;
import com.cg.ass.exception.PersonException;
import com.cg.ass.service.IRegistrationService;
import com.cg.ass.service.RegistrationServiceImpl;



@WebServlet("*.mvc")
public class RegistrationController extends HttpServlet {
	
	private IRegistrationService service;
	
	@Override
	public void init() throws ServletException {
		service = new RegistrationServiceImpl();
	}
	
    public RegistrationController() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String action = request.getServletPath();
		Person person = new Person();
		PrintWriter out=response.getWriter();
		switch (action) {
		
		case "/addPersonForm.mvc":
				System.out.println("Add person");
				RequestDispatcher dispatcher = request.getRequestDispatcher("addPersonForm.jsp");
				dispatcher.forward(request, response);
				
			
			break;
			
		case "/addPerson.mvc":
			
				String fName = request.getParameter("txtfName");
				String lName = request.getParameter("txtlName");
				String password = request.getParameter("txtpassword");
				String gender = request.getParameter("txtgender");
				String skill = request.getParameter("txtskill");
				String city = request.getParameter("txtcity");
				
				
				person.setfName(fName);
				person.setlName(lName);
				person.setPassword(password);
				person.setGender(gender);
				person.setSkill(skill);
				person.setCity(city);
				
				
			try 
			{
				service.addPerson(person);
				response.sendRedirect("index.html");  
			} 
			catch (PersonException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		case "/showall.mvc":
				
			ArrayList<Person> myPerson=null;
			try 
			{
				myPerson = service.showall();
			} 
			catch (PersonException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
				for(Person person1: myPerson)
				{
				System.out.println(" Person Data is:"+person1.getfName());
				System.out.println(" Person Data is:"+person1.getlName());
				System.out.println(" Person Data is:"+person1.getPassword());
				System.out.println(" Person Data is:"+person1.getGender());
				System.out.println(" Person Data is:"+person1.getSkill());
				System.out.println(" Person Data is:"+person1.getCity());
				
				
				
				out.println(" first Name is "+person1.getfName());out.println("<br/>");
				out.println("last Name is "+person1.getlName());out.println("<br/>");
				out.println(" password is "+person1.getPassword());out.println("<br/>");
				out.println(" gender"+person1.getGender());out.println("<br/>");
				out.println("skill set "+person1.getSkill());out.println("<br/>");
				out.println(" city"+person1.getCity());out.println("<br/>");
				
				out.println("<br/>");
				}
			break;

		default :
			break;
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
