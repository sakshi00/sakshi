package com.cg.ass.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.ass.dto.Person;
import com.cg.ass.util.DbUtil;

public class RegistrationDaoImpl implements IRegistrationDao
{
	static Connection conn = null;
	static PreparedStatement pstm = null;

	@Override
	public void addPerson(Person person) throws SQLException, NamingException
	{
		 conn = DbUtil.getConnection();
		 pstm = conn.prepareStatement("insert into registeredusers values(?,?,?,?,?,?)");
		
		 pstm.setString(1, person.getfName());
		 pstm.setString(2, person.getlName());
		 pstm.setString(3, person.getPassword());
		 pstm.setString(4, person.getGender());
		 pstm.setString(5, person.getSkill());
		 pstm.setString(6, person.getCity());
		 
		 pstm.executeUpdate();
		 
		
	}

	@Override
	public ArrayList<Person> showall() throws SQLException, NamingException  
	{
		ArrayList<Person> userList = new ArrayList<>();
		conn = DbUtil.getConnection();
		String query = "select * from registeredusers";
		
		try {
			pstm= conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			
			while(res.next())
			{
				Person person = new Person();
				person.setfName(res.getString(1));
				person.setlName(res.getString(2));
				person.setPassword(res.getString(3));
				person.setGender(res.getString(4));
				person.setSkill(res.getString(5));
				person.setCity(res.getString(6));
				
				userList.add(person);
			}
			}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userList;
	}
	

}
