package com.cg.ass.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.ass.dto.Person;

public interface IRegistrationDao 
{
	public void addPerson(Person person) throws SQLException, NamingException;
	
	public ArrayList<Person> showall() throws SQLException, NamingException;
}
