package com.cg.ass.exception;

public class PersonException extends Exception 
{

	public PersonException() {
		super();
		
	}

	public PersonException(String string) {
		// TODO Auto-generated constructor stub
	}
	

}
