package com.cg.ass.service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.ass.dao.IRegistrationDao;
import com.cg.ass.dao.RegistrationDaoImpl;
import com.cg.ass.dto.Person;
import com.cg.ass.exception.PersonException;

public class RegistrationServiceImpl implements IRegistrationService
{
	IRegistrationDao dao = new RegistrationDaoImpl();
	
	@Override
	public void addPerson(Person person) throws PersonException
	{
		
		try 
		{
			dao.addPerson(person);
		}
		catch (SQLException e) 
		{
			
			e.printStackTrace();
			throw new PersonException("Failed to insert..");
		} 
		catch (NamingException e) 
		{
			
			e.printStackTrace();
			throw new PersonException("Failed to insert..");
		}
		
	}
	
	public ArrayList<Person> showall() throws PersonException 
	{
		try {
			return dao.showall();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PersonException("Failed to show");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PersonException("Failed to show");
		}
	}

}
