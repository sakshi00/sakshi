package com.cg.ass.service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.ass.dto.Person;
import com.cg.ass.exception.PersonException;

public interface IRegistrationService
{
	public void addPerson(Person person) throws PersonException;
	public ArrayList<Person> showall() throws PersonException;
}
